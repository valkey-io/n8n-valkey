# @langchain/valkey Changelog

## 0.0.1 (unreleased)

Initial release.

### Features

- `ValkeyVectorStore` class implementing the LangChain.js `VectorStore` interface
- KNN vector similarity search via `FT.SEARCH`
- Metadata filtering with TAG, NUMERIC, and TEXT field types
- Custom index schema support for indexed metadata fields
- Batch pipeline writes for efficient document ingestion
- Configurable distance metrics: COSINE, IP, L2
- Configurable index prefixes and key layout
- Escaped TAG filter values to prevent query injection
- `fromTexts` and `fromDocuments` static factory methods
- `delete` method (by ID or drop-all)
- Add and update documents by ID with `addDocuments(docs, { ids })`
- `addDocuments` returns the document IDs, and search results set `Document.id`
- Uses `@valkey/valkey-glide` as the official Valkey Node.js client

### Fixes

- TAG filters with an array value (for example `{ category: ["news", "tech"] }`)
  failed with a query syntax error on every valkey-search version. The query now
  uses the `@field:{a | b}` format. An empty array now throws a clear error.
- Metadata filters (TAG, NUMERIC, TEXT) failed on a valkey-search 1.0.x cluster
  with ``Index: field `metadata.<field>` not exists``. The index stored each
  metadata field in the hash field `<metadataKey>.<field>` with the `AS` alias
  `<metadataKey>_<field>`, and the valkey-search 1.0.x cluster coordinator
  rejects a query on an aliased field. The alias was necessary because
  valkey-search 1.2+ rejects `.` in an attribute name. The hash fields are now
  named `<metadataKey>_<field>` (for example `metadata_category`), and the index
  uses this name with no alias. This works on 1.0.x and 1.2+, standalone and
  cluster. The query strings do not change.
  An index and data written by an earlier build of this package use the old
  `<metadataKey>.<field>` hash fields, which the new index does not read. There
  is no migration code: drop the index (`delete({ deleteAll: true })`), delete
  the old document keys under `keyPrefix` (FT.DROPINDEX does not delete them),
  and add the documents again.

### Attribution

Core implementation ported from [daric93/langchainjs](https://github.com/daric93/langchainjs/tree/feature/valkey-vector-store)
(`libs/providers/langchain-valkey/`), originally submitted upstream as
[langchain-ai/langchainjs#9915](https://github.com/langchain-ai/langchainjs/pull/9915).
