# @langchain/valkey

[![npm version](https://img.shields.io/npm/v/@langchain/valkey)](https://www.npmjs.com/package/@langchain/valkey)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue)](LICENSE)

LangChain.js vector store integration backed by [Valkey Search](https://github.com/valkey-io/valkey-search).

## Prerequisites

- Node.js >= 20
- A running [Valkey](https://valkey.io) instance with the [valkey-search](https://github.com/valkey-io/valkey-search) module loaded

### Compatibility

The library works with valkey-search 1.0.x and 1.2+ (tested with 1.0.3 and
1.2.1). On Amazon ElastiCache, these correspond to Valkey 8.2 (vector search
with TAG and NUMERIC filters) and Valkey 9.0+ (adds full-text search).

`TEXT` fields in `customSchema` need valkey-search 1.2+ or ElastiCache for
Valkey 9.0+. On valkey-search 1.0.x, creating an index with a `TEXT` field
fails.

## Installation

```bash
npm install @langchain/valkey @langchain/core @valkey/valkey-glide
```

## Quick Start

```typescript
import { GlideClient } from "@valkey/valkey-glide";
import { OpenAIEmbeddings } from "@langchain/openai";
import { ValkeyVectorStore } from "@langchain/valkey";

const client = await GlideClient.createClient({ addresses: [{ host: "localhost", port: 6379 }] });

const vectorStore = new ValkeyVectorStore(new OpenAIEmbeddings(), {
  valkeyClient: client,
  indexName: "my-index",
});

// Add documents
await vectorStore.addDocuments([
  { pageContent: "Valkey is a fast, open-source key-value store.", metadata: {} },
]);

// Search
const results = await vectorStore.similaritySearch("key-value store", 3);
console.log(results);

await client.close();
```

## Configuration

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `valkeyClient` | `GlideClient \| GlideClusterClient` | required | Valkey GLIDE client instance |
| `indexName` | `string` | required | Name of the FT index |
| `indexOptions` | `CreateSchemaFlatVectorField \| CreateSchemaHNSWVectorField` | HNSW / COSINE | Vector index algorithm and distance metric |
| `keyPrefix` | `string` | `doc:<indexName>:` | Key prefix for stored documents |
| `contentKey` | `string` | `content` | Hash field for document text |
| `metadataKey` | `string` | `metadata` | Hash field for JSON metadata blob |
| `vectorKey` | `string` | `content_vector` | Hash field for the embedding vector |
| `ttl` | `number` | — | TTL in seconds for stored keys, applied again when a document is replaced by ID |
| `customSchema` | `Record<string, CustomSchemaField>` | — | Indexed metadata fields for filtering |

## Distance Metrics

`COSINE` (default), `L2`, `IP`

## Metadata Filtering

Define a `customSchema` to enable server-side metadata filtering:

```typescript
import { SchemaFieldTypes, ValkeyVectorStore } from "@langchain/valkey";

const vectorStore = new ValkeyVectorStore(embeddings, {
  valkeyClient: client,
  indexName: "my-index",
  customSchema: {
    category: { type: SchemaFieldTypes.TAG },
    year: { type: SchemaFieldTypes.NUMERIC },
  },
});

const results = await vectorStore.similaritySearchVectorWithScoreAndMetadata(
  queryVector,
  5,
  { category: "news", year: { min: 2020, max: 2024 } }
);
```

## Cluster Client

`ValkeyVectorStore` accepts a `GlideClusterClient` in place of a `GlideClient`.
Reads and writes both work against a Valkey Cluster: `createIndex`,
`addVectors` / `addDocuments` / the factory methods (with `ids` and `ttl`),
the search methods, and `delete`.

```typescript
import { GlideClusterClient } from "@valkey/valkey-glide";
import { ValkeyVectorStore } from "@langchain/valkey";

const client = await GlideClusterClient.createClient({
  addresses: [{ host: "localhost", port: 7000 }],
});

const vectorStore = new ValkeyVectorStore(embeddings, {
  valkeyClient: client,
  indexName: "my-index",
});

// Writes and searches work against a cluster:
await vectorStore.addDocuments([
  { pageContent: "Valkey is a key-value store", metadata: {} },
]);
const results = await vectorStore.similaritySearch("key-value store", 3);
```

> **Note:** Every cluster node must load valkey-search with `--use-coordinator`
> (for example `loadmodule /usr/lib/valkey/libsearch.so --use-coordinator`).
> Without the coordinator, a search sees only the keys of one shard.

## Factory Methods

Two static factory methods create and populate a store in a single call.

### `fromTexts`

```typescript
import { ValkeyVectorStore } from "@langchain/valkey";

const vectorStore = await ValkeyVectorStore.fromTexts(
  ["apple", "banana", "cherry"],
  [{ fruit: "apple" }, { fruit: "banana" }, { fruit: "cherry" }],
  embeddings,
  { valkeyClient: client, indexName: "fruits" }
);

const results = await vectorStore.similaritySearch("apple", 1);
```

### `fromDocuments`

```typescript
import { Document } from "@langchain/core/documents";
import { ValkeyVectorStore } from "@langchain/valkey";

const docs = [
  new Document({ pageContent: "Valkey is fast", metadata: { topic: "valkey" } }),
  new Document({ pageContent: "LangChain is flexible", metadata: { topic: "langchain" } }),
];

const vectorStore = await ValkeyVectorStore.fromDocuments(docs, embeddings, {
  valkeyClient: client,
  indexName: "docs",
});
```

## Adding and Updating Documents by ID

Pass `ids` to choose each document's ID. Writing a document with an ID that
already exists replaces it.

```typescript
// Add with your own IDs. The returned IDs can be passed to `ids` or `delete`.
const ids = await vectorStore.addDocuments(
  [
    { pageContent: "Valkey is fast", metadata: { topic: "valkey", draft: true } },
    { pageContent: "LangChain is flexible", metadata: { topic: "langchain" } },
  ],
  { ids: ["doc1", "doc2"] },
);
// ids: ["doc1", "doc2"]

// Update doc1: the stored document is replaced whole
await vectorStore.addDocuments(
  [{ pageContent: "Valkey is very fast", metadata: { topic: "valkey" } }],
  { ids: ["doc1"] },
);

// Search results carry the ID
const [result] = await vectorStore.similaritySearch("fast", 1);
console.log(result.id); // "doc1"
```

- **Keys.** Each ID is stored under `keyPrefix`, so `doc1` becomes
  `doc:<indexName>:doc1`, the same key `delete({ ids })` uses. An ID that
  already starts with `keyPrefix` is not prefixed again. Returned IDs and
  `Document.id` never include the prefix.
- **Replace, not merge.** An update deletes the old document and writes the new
  one. Metadata fields missing from the new document are removed (`draft`
  above). The two steps are not atomic, so a search running at the same moment
  can briefly miss the document, and concurrent writes to the same ID are not
  isolated from each other.
- **Unknown IDs are created.** Writing an ID that doesn't exist adds a new
  document.
- **TTL is reset.** An updated document gets the store's `ttl` again, or no
  expiry if the store has no `ttl`. Its previous expiry is not kept.
- **Without `ids`,** each document gets a random ID. Adding the same content
  twice stores two documents.

`addVectors` throws before creating the index or writing anything if
`documents`, `vectors` and `ids` differ in length, if vectors differ in length
or contain `NaN` or `Infinity`, if an ID is empty or appears twice in one call,
or if a document's metadata doesn't match `customSchema`.

## Deleting Documents

Delete specific documents by ID, or drop the entire index:

```typescript
// Delete specific documents by ID (IDs are auto-prefixed with keyPrefix).
// Use the IDs returned by addDocuments, or Document.id from search results.
await vectorStore.delete({ ids: ["doc1", "doc2", "doc3"] });

// Delete everything by dropping the whole index
await vectorStore.delete({ deleteAll: true });
```

## Index Options

Choose the vector index algorithm (`FLAT` or `HNSW`) and distance metric via
`indexOptions`.

### HNSW (default)

```typescript
import { VectorAlgorithms, ValkeyVectorStore } from "@langchain/valkey";

const vectorStore = new ValkeyVectorStore(embeddings, {
  valkeyClient: client,
  indexName: "hnsw-index",
  indexOptions: {
    ALGORITHM: VectorAlgorithms.HNSW,
    DISTANCE_METRIC: "COSINE",
    M: 16,
    EF_CONSTRUCTION: 200,
    EF_RUNTIME: 10,
  },
});
```

### FLAT

```typescript
import { VectorAlgorithms, ValkeyVectorStore } from "@langchain/valkey";

const vectorStore = new ValkeyVectorStore(embeddings, {
  valkeyClient: client,
  indexName: "flat-index",
  indexOptions: {
    ALGORITHM: VectorAlgorithms.FLAT,
    DISTANCE_METRIC: "L2",
  },
});
```

### Distance Metrics

All three metrics are supported via `DISTANCE_METRIC`:

- `COSINE` — cosine similarity (default)
- `L2` — Euclidean distance
- `IP` — inner product

## Known Limitations

- **Large integer precision.** Numbers beyond `Number.MAX_SAFE_INTEGER`
  (2^53 − 1) lose precision because JavaScript represents all numbers as IEEE
  754 float64. Avoid storing such values in NUMERIC metadata fields.
- **`filter` param requires a custom schema.** The `filter` parameter on
  `similaritySearchVectorWithScore` is not functional without a `customSchema`.
  Define indexed metadata fields via `customSchema` and use
  `similaritySearchVectorWithScoreAndMetadata` for server-side filtering.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

Apache 2.0 — see [LICENSE](LICENSE).
